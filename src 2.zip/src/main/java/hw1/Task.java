package hw1;

import java.util.Arrays;

public class Task {

  /**
   * Solves the two-sum problem.
   *
   * @param nums an array of integers (at least two), sorted in ascending order.
   * @param target an integer value.
   *        There will be exactly one pair of values on nums that sum to target.
   * @return an array of integers with exactly two elements:
   *       indices of the two numbers in the array nums such that they add up to the target.
   */
  public static int[] twoSum(int[] nums, int target) {
    int numOfNums = nums.length;
    int[] result = new int[2];
    for (int i = 0; i < numOfNums - 1; i++) {
      for (int j = 1; j < numOfNums; j++) {
        if ((nums[i] + nums[j]) == target) {
          result[0] = i;
          result[1] = j;
          return result;
        }
      }
    }
    return null;
  }

  /**
   * Execution starts here.
   * @param args command-line arguments (not used here).
   */
  public static void main(String[] args) {
    int[] input = new int[]{2, 7, 11, 15};
    int target = 13;
    int[] result = twoSum(input, target);
    System.out.println(Arrays.toString(result));
  }
}